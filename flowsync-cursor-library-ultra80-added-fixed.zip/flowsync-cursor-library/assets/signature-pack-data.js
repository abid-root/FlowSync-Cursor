(function () {
  const addonCategories = [
    {
        "id":  "signature-structure",
        "num":  "01",
        "title":  "Signature Structure",
        "desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "icon":  "structure",
        "effects":  [
                        "sig-fractured-cursor",
                        "sig-hinge-bracket",
                        "sig-dotted-lasso",
                        "sig-blueprint-corner",
                        "sig-ruler-snap",
                        "sig-folded-grid",
                        "sig-anchor-pin",
                        "sig-cross-section",
                        "sig-orbit-stamp",
                        "sig-elastic-box"
                    ]
    },
    {
        "id":  "signature-energy",
        "num":  "02",
        "title":  "Signature Energy",
        "desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "icon":  "energy",
        "effects":  [
                        "sig-pulse-beacon",
                        "sig-wave-ladder",
                        "sig-signal-fan",
                        "sig-electric-fork",
                        "sig-sonar-bubble",
                        "sig-phase-rings",
                        "sig-storm-ticks",
                        "sig-voltage-teeth",
                        "sig-ripple-gate",
                        "sig-light-drift"
                    ]
    },
    {
        "id":  "signature-matter",
        "num":  "03",
        "title":  "Signature Matter",
        "desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "icon":  "matter",
        "effects":  [
                        "sig-liquid-drop",
                        "sig-sand-hourglass",
                        "sig-dust-collapse",
                        "sig-pebble-jump",
                        "sig-cloth-fray",
                        "sig-paper-kite",
                        "sig-graphite-smear",
                        "sig-wax-melt",
                        "sig-pearl-chain",
                        "sig-feather-fall"
                    ]
    },
    {
        "id":  "signature-data-ui",
        "num":  "04",
        "title":  "Signature Data UI",
        "desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "icon":  "dataui",
        "effects":  [
                        "sig-command-stack",
                        "sig-packet-hop",
                        "sig-cursor-clone",
                        "sig-keycap-pop",
                        "sig-loading-orbit",
                        "sig-slider-ghost",
                        "sig-window-shard",
                        "sig-menu-dots",
                        "sig-code-shiver",
                        "sig-upload-burst"
                    ]
    },
    {
        "id":  "signature-cosmic",
        "num":  "05",
        "title":  "Signature Cosmic",
        "desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "icon":  "cosmic",
        "effects":  [
                        "sig-moon-crescent",
                        "sig-compass-break",
                        "sig-gravity-dots",
                        "sig-constellation-snap",
                        "sig-eclipse-gate",
                        "sig-cube-wire",
                        "sig-map-pin-pop",
                        "sig-satellite-sweep",
                        "sig-spiral-beads",
                        "sig-star-dial"
                    ]
    },
    {
        "id":  "signature-basic-marks",
        "num":  "06",
        "title":  "Basic Cursor Marks",
        "desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "icon":  "basic",
        "effects":  [
                        "bc-soft-dot",
                        "bc-clean-ring",
                        "bc-cross-plus",
                        "bc-tiny-plus",
                        "bc-cursor-halo",
                        "bc-square-pulse",
                        "bc-triangle-tick",
                        "bc-underline-trail",
                        "bc-corner-ticks",
                        "bc-mini-dash"
                    ]
    },
    {
        "id":  "signature-interface-basics",
        "num":  "07",
        "title":  "Interface Basics",
        "desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "icon":  "ui",
        "effects":  [
                        "bc-default-pointer",
                        "bc-caret-blink",
                        "bc-target-dot",
                        "bc-click-ripple",
                        "bc-small-spark",
                        "bc-plain-ring",
                        "bc-follow-bar",
                        "bc-axis-mark",
                        "bc-mono-dot",
                        "bc-quiet-bubble"
                    ]
    }
];
  const addonEffects = [
    {
        "key":  "sig-fractured-cursor",
        "name":  "Fractured Cursor",
        "desc":  "Cursor-arrow fragments split away from the pointer.",
        "kind":  "signature-rich",
        "mode":  "fracturedCursor",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-hinge-bracket",
        "name":  "Hinge Bracket",
        "desc":  "Four hinged brackets fold open around the cursor.",
        "kind":  "signature-rich",
        "mode":  "hingeBracket",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-dotted-lasso",
        "name":  "Dotted Lasso",
        "desc":  "A dotted rope circle wraps and breaks apart.",
        "kind":  "signature-rich",
        "mode":  "dottedLasso",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-blueprint-corner",
        "name":  "Blueprint Corner",
        "desc":  "Technical blueprint corners draw and fade.",
        "kind":  "signature-rich",
        "mode":  "blueprintCorner",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-ruler-snap",
        "name":  "Ruler Snap",
        "desc":  "Tiny ruler ticks snap in measured steps.",
        "kind":  "signature-rich",
        "mode":  "rulerSnap",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-folded-grid",
        "name":  "Folded Grid",
        "desc":  "Small grid tiles flip like folded panels.",
        "kind":  "signature-rich",
        "mode":  "foldedGrid",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-anchor-pin",
        "name":  "Anchor Pin",
        "desc":  "A small pin drops with a grounded pulse.",
        "kind":  "signature-rich",
        "mode":  "anchorPin",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-cross-section",
        "name":  "Cross Section",
        "desc":  "Cross-hatched section lines slice through the cursor.",
        "kind":  "signature-rich",
        "mode":  "crossSection",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-orbit-stamp",
        "name":  "Orbit Stamp",
        "desc":  "A square stamp rotates with dusty edges.",
        "kind":  "signature-rich",
        "mode":  "orbitStamp",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-elastic-box",
        "name":  "Elastic Box",
        "desc":  "A box stretches and rebounds around movement.",
        "kind":  "signature-rich",
        "mode":  "elasticBox",
        "cat_id":  "signature-structure",
        "cat_num":  "01",
        "cat_title":  "Signature Structure",
        "cat_desc":  "Cursor effects built from grids, brackets, cursor ghosts and structural marks.",
        "cat_icon":  "structure",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-pulse-beacon",
        "name":  "Pulse Beacon",
        "desc":  "A beacon dot sends two clean pulse rings.",
        "kind":  "signature-rich",
        "mode":  "pulseBeacon",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-wave-ladder",
        "name":  "Wave Ladder",
        "desc":  "A ladder of waveform bars rises around the cursor.",
        "kind":  "signature-rich",
        "mode":  "waveLadder",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-signal-fan",
        "name":  "Signal Fan",
        "desc":  "Signal arcs fan out from one side of the pointer.",
        "kind":  "signature-rich",
        "mode":  "signalFan",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-electric-fork",
        "name":  "Electric Fork",
        "desc":  "Forked electric branches snap outward.",
        "kind":  "signature-rich",
        "mode":  "electricFork",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-sonar-bubble",
        "name":  "Sonar Bubble",
        "desc":  "A sonar bubble expands with small echo dots.",
        "kind":  "signature-rich",
        "mode":  "sonarBubble",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-phase-rings",
        "name":  "Phase Rings",
        "desc":  "Two offset phase rings pass through each other.",
        "kind":  "signature-rich",
        "mode":  "phaseRings",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-storm-ticks",
        "name":  "Storm Ticks",
        "desc":  "Short storm ticks rotate in broken bursts.",
        "kind":  "signature-rich",
        "mode":  "stormTicks",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-voltage-teeth",
        "name":  "Voltage Teeth",
        "desc":  "Small zigzag teeth jump away from the cursor.",
        "kind":  "signature-rich",
        "mode":  "voltageTeeth",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-ripple-gate",
        "name":  "Ripple Gate",
        "desc":  "Two gate lines open while ripples pass through.",
        "kind":  "signature-rich",
        "mode":  "rippleGate",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-light-drift",
        "name":  "Light Drift",
        "desc":  "Soft light motes drift slowly behind movement.",
        "kind":  "signature-rich",
        "mode":  "lightDrift",
        "cat_id":  "signature-energy",
        "cat_num":  "02",
        "cat_title":  "Signature Energy",
        "cat_desc":  "Wave, signal, electric and pulse-based cursor effects.",
        "cat_icon":  "energy",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-liquid-drop",
        "name":  "Liquid Drop",
        "desc":  "A stretched liquid drop falls and dissolves.",
        "kind":  "signature-rich",
        "mode":  "liquidDrop",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-sand-hourglass",
        "name":  "Sand Hourglass",
        "desc":  "Two tiny triangles pour dust between them.",
        "kind":  "signature-rich",
        "mode":  "sandHourglass",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-dust-collapse",
        "name":  "Dust Collapse",
        "desc":  "Dust starts outside and collapses inward.",
        "kind":  "signature-rich",
        "mode":  "dustCollapse",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-pebble-jump",
        "name":  "Pebble Jump",
        "desc":  "Small pebbles jump and fall with weight.",
        "kind":  "signature-rich",
        "mode":  "pebbleJump",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-cloth-fray",
        "name":  "Cloth Fray",
        "desc":  "Frayed cloth strands tear away from the cursor.",
        "kind":  "signature-rich",
        "mode":  "clothFray",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-paper-kite",
        "name":  "Paper Kite",
        "desc":  "A tiny paper kite flips and drifts.",
        "kind":  "signature-rich",
        "mode":  "paperKite",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-graphite-smear",
        "name":  "Graphite Smear",
        "desc":  "A dry graphite smear drags behind movement.",
        "kind":  "signature-rich",
        "mode":  "graphiteSmear",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-wax-melt",
        "name":  "Wax Melt",
        "desc":  "Rounded wax drops stretch downward.",
        "kind":  "signature-rich",
        "mode":  "waxMelt",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-pearl-chain",
        "name":  "Pearl Chain",
        "desc":  "Small pearls follow a curved chain path.",
        "kind":  "signature-rich",
        "mode":  "pearlChain",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-feather-fall",
        "name":  "Feather Fall",
        "desc":  "Light feather marks fall in different angles.",
        "kind":  "signature-rich",
        "mode":  "featherFall",
        "cat_id":  "signature-matter",
        "cat_num":  "03",
        "cat_title":  "Signature Matter",
        "cat_desc":  "Liquid, paper, sand, cloth, dust and material motion.",
        "cat_icon":  "matter",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-command-stack",
        "name":  "Command Stack",
        "desc":  "Stacked command prompts rise like terminal echoes.",
        "kind":  "signature-rich",
        "mode":  "commandStack",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-packet-hop",
        "name":  "Packet Hop",
        "desc":  "A packet dot hops across a short trace line.",
        "kind":  "signature-rich",
        "mode":  "packetHop",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-cursor-clone",
        "name":  "Cursor Clone",
        "desc":  "Ghost cursor arrows duplicate and fade.",
        "kind":  "signature-rich",
        "mode":  "cursorClone",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-keycap-pop",
        "name":  "Keycap Pop",
        "desc":  "Small keyboard keycaps pop near the pointer.",
        "kind":  "signature-rich",
        "mode":  "keycapPop",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-loading-orbit",
        "name":  "Loading Orbit",
        "desc":  "Three loading dots orbit and shoot away.",
        "kind":  "signature-rich",
        "mode":  "loadingOrbit",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-slider-ghost",
        "name":  "Slider Ghost",
        "desc":  "A slider knob leaves a small ghost trail.",
        "kind":  "signature-rich",
        "mode":  "sliderGhost",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-window-shard",
        "name":  "Window Shard",
        "desc":  "Tiny app-window shards break apart.",
        "kind":  "signature-rich",
        "mode":  "windowShard",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-menu-dots",
        "name":  "Menu Dots",
        "desc":  "Three menu dots split in different directions.",
        "kind":  "signature-rich",
        "mode":  "menuDots",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-code-shiver",
        "name":  "Code Shiver",
        "desc":  "Tiny code marks shiver and vanish.",
        "kind":  "signature-rich",
        "mode":  "codeShiver",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-upload-burst",
        "name":  "Upload Burst",
        "desc":  "An upload arrow breaks into upward particles.",
        "kind":  "signature-rich",
        "mode":  "uploadBurst",
        "cat_id":  "signature-data-ui",
        "cat_num":  "04",
        "cat_title":  "Signature Data UI",
        "cat_desc":  "Command stacks, packet jumps, cursor clones and UI micro-motion.",
        "cat_icon":  "dataui",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-moon-crescent",
        "name":  "Moon Crescent",
        "desc":  "A crescent moon slips past the cursor.",
        "kind":  "signature-rich",
        "mode":  "moonCrescent",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-compass-break",
        "name":  "Compass Break",
        "desc":  "Compass ticks break toward four directions.",
        "kind":  "signature-rich",
        "mode":  "compassBreak",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-gravity-dots",
        "name":  "Gravity Dots",
        "desc":  "Dots curve around the pointer like gravity.",
        "kind":  "signature-rich",
        "mode":  "gravityDots",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-constellation-snap",
        "name":  "Constellation Snap",
        "desc":  "Small points connect into a quick constellation.",
        "kind":  "signature-rich",
        "mode":  "constellationSnap",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-eclipse-gate",
        "name":  "Eclipse Gate",
        "desc":  "Two dark-light discs cross like an eclipse.",
        "kind":  "signature-rich",
        "mode":  "eclipseGate",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-cube-wire",
        "name":  "Cube Wire",
        "desc":  "A tiny wireframe cube unfolds and fades.",
        "kind":  "signature-rich",
        "mode":  "cubeWire",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-map-pin-pop",
        "name":  "Map Pin Pop",
        "desc":  "A small map pin pops and leaves a ring.",
        "kind":  "signature-rich",
        "mode":  "mapPinPop",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-satellite-sweep",
        "name":  "Satellite Sweep",
        "desc":  "A satellite dot sweeps around an orbit line.",
        "kind":  "signature-rich",
        "mode":  "satelliteSweep",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-spiral-beads",
        "name":  "Spiral Beads",
        "desc":  "Beads spiral outward in a controlled curve.",
        "kind":  "signature-rich",
        "mode":  "spiralBeads",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "sig-star-dial",
        "name":  "Star Dial",
        "desc":  "A dial of star ticks rotates open.",
        "kind":  "signature-rich",
        "mode":  "starDial",
        "cat_id":  "signature-cosmic",
        "cat_num":  "05",
        "cat_title":  "Signature Cosmic",
        "cat_desc":  "Moon, compass, gravity, constellation and geometric orbit effects.",
        "cat_icon":  "cosmic",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-soft-dot",
        "name":  "Soft Dot",
        "desc":  "A quiet dot follows the cursor with soft delay.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  1,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-clean-ring",
        "name":  "Clean Ring",
        "desc":  "A thin ring follows the pointer cleanly.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  2,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-cross-plus",
        "name":  "Cross Plus",
        "desc":  "A minimal plus mark follows the cursor.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  3,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-tiny-plus",
        "name":  "Tiny Plus",
        "desc":  "A smaller plus mark with lighter motion.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  4,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-cursor-halo",
        "name":  "Cursor Halo",
        "desc":  "A subtle halo follows cursor movement.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  5,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-square-pulse",
        "name":  "Square Pulse",
        "desc":  "A small square pulse tracks the pointer.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  6,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-triangle-tick",
        "name":  "Triangle Tick",
        "desc":  "A tiny triangle tick follows with rotation.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  7,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-underline-trail",
        "name":  "Underline Trail",
        "desc":  "A small underline bar follows beneath the cursor.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  8,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-corner-ticks",
        "name":  "Corner Ticks",
        "desc":  "Four small corner ticks follow the pointer.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  9,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-mini-dash",
        "name":  "Mini Dash",
        "desc":  "A tiny dash follows cursor direction.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-basic-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple follow-cursor marks: rings, dots, plus signs, corners and bars.",
        "cat_icon":  "basic",
        "index":  10,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-default-pointer",
        "name":  "Default Pointer",
        "desc":  "A small pointer arrow follows the cursor.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  1,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-caret-blink",
        "name":  "Caret Blink",
        "desc":  "A blinking caret follows like a text cursor.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  2,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-target-dot",
        "name":  "Target Dot",
        "desc":  "A clean target dot follows cursor movement.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  3,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-click-ripple",
        "name":  "Click Ripple",
        "desc":  "A simple ripple pulse follows the pointer.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  4,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-small-spark",
        "name":  "Small Spark",
        "desc":  "A tiny spark mark follows with light rotation.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  5,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-plain-ring",
        "name":  "Plain Ring",
        "desc":  "A plain neutral ring follows the pointer.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  6,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-follow-bar",
        "name":  "Follow Bar",
        "desc":  "A short bar follows cursor direction.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  7,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-axis-mark",
        "name":  "Axis Mark",
        "desc":  "A small x/y axis mark follows the cursor.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  8,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-mono-dot",
        "name":  "Mono Dot",
        "desc":  "A simple mono dot with low movement delay.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  9,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-quiet-bubble",
        "name":  "Quiet Bubble",
        "desc":  "A small soft bubble follows the cursor.",
        "kind":  "signature-basic",
        "mode":  "basic",
        "cat_id":  "signature-interface-basics",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI-style cursor helpers with clean, simple follow motion.",
        "cat_icon":  "ui",
        "index":  10,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    }
];

  const addonCategoryIds = new Set(addonCategories.map((cat) => cat.id));
  const addonEffectKeys = new Set(addonEffects.map((fx) => fx.key));

  // Add-only mode:
  // only replace this Signature Pack if it already exists from an earlier run.
  // Existing mega/premium/old categories are not removed.
  const oldAddonCategoryIds = new Set([
    "signature-structure",
    "signature-energy",
    "signature-matter",
    "signature-data-ui",
    "signature-cosmic",
    "signature-basic-marks",
    "signature-interface-basics"
  ]);

  // Only remove Signature Pack's own keys on re-run to prevent duplicates.
  const oldAddonEffectKeys = new Set([
    "sig-fractured-cursor",
    "sig-hinge-bracket",
    "sig-dotted-lasso",
    "sig-blueprint-corner",
    "sig-ruler-snap",
    "sig-folded-grid",
    "sig-anchor-pin",
    "sig-cross-section",
    "sig-orbit-stamp",
    "sig-elastic-box",
    "sig-pulse-beacon",
    "sig-wave-ladder",
    "sig-signal-fan",
    "sig-electric-fork",
    "sig-sonar-bubble",
    "sig-phase-rings",
    "sig-storm-ticks",
    "sig-voltage-teeth",
    "sig-ripple-gate",
    "sig-light-drift",
    "sig-liquid-drop",
    "sig-sand-hourglass",
    "sig-dust-collapse",
    "sig-pebble-jump",
    "sig-cloth-fray",
    "sig-paper-kite",
    "sig-graphite-smear",
    "sig-wax-melt",
    "sig-pearl-chain",
    "sig-feather-fall",
    "sig-command-stack",
    "sig-packet-hop",
    "sig-cursor-clone",
    "sig-keycap-pop",
    "sig-loading-orbit",
    "sig-slider-ghost",
    "sig-window-shard",
    "sig-menu-dots",
    "sig-code-shiver",
    "sig-upload-burst",
    "sig-moon-crescent",
    "sig-compass-break",
    "sig-gravity-dots",
    "sig-constellation-snap",
    "sig-eclipse-gate",
    "sig-cube-wire",
    "sig-map-pin-pop",
    "sig-satellite-sweep",
    "sig-spiral-beads",
    "sig-star-dial",
    "bc-soft-dot",
    "bc-clean-ring",
    "bc-cross-plus",
    "bc-tiny-plus",
    "bc-cursor-halo",
    "bc-square-pulse",
    "bc-triangle-tick",
    "bc-underline-trail",
    "bc-corner-ticks",
    "bc-mini-dash",
    "bc-default-pointer",
    "bc-caret-blink",
    "bc-target-dot",
    "bc-click-ripple",
    "bc-small-spark",
    "bc-plain-ring",
    "bc-follow-bar",
    "bc-axis-mark",
    "bc-mono-dot",
    "bc-quiet-bubble"
  ]);

  window.COLD_DATA = (window.COLD_DATA || [])
    .filter((cat) => !oldAddonCategoryIds.has(cat.id) && !addonCategoryIds.has(cat.id))
    .map((cat) => ({
      ...cat,
      effects: (cat.effects || []).filter((key) => !oldAddonEffectKeys.has(key) && !addonEffectKeys.has(key))
    }))
    .filter((cat) => (cat.effects || []).length > 0);

  window.COLD_EFFECTS = (window.COLD_EFFECTS || [])
    .filter((fx) => !oldAddonEffectKeys.has(fx.key) && !addonEffectKeys.has(fx.key));

  const start = window.COLD_DATA.length + 1;

  addonCategories.forEach((cat, index) => {
    const num = String(start + index).padStart(2, "0");
    const normalized = { ...cat, num };
    window.COLD_DATA.push(normalized);

    addonEffects
      .filter((fx) => fx.cat_id === cat.id)
      .forEach((fx) => {
        window.COLD_EFFECTS.push({
          ...fx,
          cat_num: num,
          cat_title: normalized.title,
          cat_desc: normalized.desc,
          cat_icon: normalized.icon
        });
      });
  });

  window.SIGNATURE_PACK_CATEGORIES = addonCategories;
  window.SIGNATURE_PACK_EFFECTS = addonEffects;
})();