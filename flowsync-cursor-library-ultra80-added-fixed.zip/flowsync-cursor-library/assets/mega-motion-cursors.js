
(function () {
  if (typeof COLD_FX === "undefined") return;

  const oldSpawn = COLD_FX.spawn.bind(COLD_FX);
  const oldClear = COLD_FX.clear ? COLD_FX.clear.bind(COLD_FX) : null;

  const MEGA_KEYS = new Set((window.MEGA_MOTION_EFFECTS || []).map((fx) => fx.key));
  const BASIC_STATES = new WeakMap();

  function rand(a, b) {
    return a + Math.random() * (b - a);
  }

  function pick(items) {
    return items[Math.floor(Math.random() * items.length)];
  }

  function pal(effect) {
    const light = document.documentElement.getAttribute("data-theme") === "light";
    return light ? (effect.light || effect.dark) : (effect.dark || effect.light);
  }

  function piece(layer, cls, x, y, effect, text) {
    const p = pal(effect);
    const el = document.createElement("span");
    el.className = "mega-fx " + cls;
    el.setAttribute("aria-hidden", "true");
    if (text != null) el.textContent = text;
    el.style.left = x + "px";
    el.style.top = y + "px";
    el.style.setProperty("--a", p.a);
    el.style.setProperty("--b", p.b);
    el.style.setProperty("--ink", p.ink);
    layer.appendChild(el);
    return el;
  }

  function fly(el, dx, dy, ms, scale = 1, rot = 0, anim = "megaFly") {
    el.style.setProperty("--dx", dx + "px");
    el.style.setProperty("--dy", dy + "px");
    el.style.setProperty("--sc", scale);
    el.style.setProperty("--rot", rot + "deg");
    el.style.animation = anim + " " + ms + "ms cubic-bezier(.16,.82,.28,1) forwards";
    setTimeout(() => el.remove(), ms + 80);
  }

  function line(layer, cls, x, y, effect, w, rot, dx, dy, ms) {
    const el = piece(layer, cls, x, y, effect);
    el.style.setProperty("--w", w + "px");
    fly(el, dx, dy, ms, rand(.75, 1.12), rot);
  }

  function dot(layer, cls, x, y, effect, s, dx, dy, ms, rot = 0) {
    const el = piece(layer, cls, x, y, effect);
    el.style.setProperty("--s", s + "px");
    fly(el, dx, dy, ms, rand(.45, 1.15), rot);
  }

  function textMark(layer, cls, x, y, effect, text, dx, dy, ms, rot = 0) {
    const el = piece(layer, cls, x, y, effect, text);
    fly(el, dx, dy, ms, rand(.75, 1.1), rot);
  }

  function shape(layer, cls, x, y, effect, dx, dy, ms, rot = 0) {
    const el = piece(layer, cls, x, y, effect);
    fly(el, dx, dy, ms, rand(.55, 1.15), rot);
  }

  function ring(layer, cls, x, y, effect, ms = 780) {
    const el = piece(layer, cls, x, y, effect);
    el.style.animation = "megaPulse " + ms + "ms ease-out forwards";
    setTimeout(() => el.remove(), ms + 80);
  }

  const RICH = {
    ashSpiral(effect, layer, x, y) {
      const base = performance.now() / 260;
      for (let i = 0; i < 5; i++) {
        const a = base + i * 1.22 + rand(-.16, .16);
        const d = rand(22, 62);
        dot(layer, "mega-ash-dot", x + Math.cos(a) * 8, y + Math.sin(a) * 8, effect, rand(3,7), Math.cos(a)*d, Math.sin(a)*d-rand(22,54), 860+i*45, rand(-180,180));
      }
    },
    emberVeil(effect, layer, x, y) {
      for (let i=0;i<6;i++) line(layer,"mega-warm-ember",x+rand(-14,14),y+rand(-8,10),effect,rand(8,22),rand(-90,90),rand(-28,28),rand(-86,-28),760+i*45);
    },
    smokeKnot(effect, layer, x, y) {
      for (let i=0;i<4;i++) dot(layer,"mega-smoke-blob",x+rand(-8,8),y+rand(-8,8),effect,rand(20,44),rand(-34,34),rand(-48,8),920+i*70,rand(-90,90));
    },
    cinderLift(effect, layer, x, y) {
      for (let i=0;i<6;i++) shape(layer,"mega-cinder",x+rand(-7,7),y+rand(-7,7),effect,rand(-40,40),rand(-95,-20),720+i*35,rand(-180,180));
    },
    sootComet(effect, layer, x, y) {
      for (let i=0;i<4;i++) line(layer,"mega-soot-comet",x,y,effect,rand(26,48),rand(-30,30),rand(-70,-20),rand(-22,22),680+i*50);
    },
    burntPollen(effect, layer, x, y) {
      for (let i=0;i<8;i++) dot(layer,"mega-pollen",x+rand(-12,12),y+rand(-12,12),effect,rand(3,6),rand(-55,55),rand(-55,20),780+i*30);
    },
    charcoalRain(effect, layer, x, y) {
      for (let i=0;i<7;i++) dot(layer,"mega-charcoal",x+rand(-18,18),y+rand(-10,8),effect,rand(4,8),rand(-16,16),rand(34,86),940+i*40,rand(-100,100));
    },
    vaporStitch(effect, layer, x, y) {
      for (let i=0;i<5;i++) line(layer,"mega-vapor-stitch",x+i*6-12,y+rand(-10,10),effect,rand(12,26),rand(-20,20),rand(-36,36),rand(-28,28),700+i*35);
    },
    ghostAsh(effect, layer, x, y) {
      for (let i=0;i<3;i++) ring(layer,"mega-ghost-ring",x+rand(-8,8),y+rand(-8,8),effect,860+i*80);
    },
    coalFlicker(effect, layer, x, y) {
      for (let i=0;i<5;i++) dot(layer,"mega-coal",x+rand(-6,6),y+rand(-6,6),effect,rand(5,10),rand(-24,24),rand(-32,12),620+i*30);
    },

    glassScratch(effect, layer, x, y) {
      for (let i=0;i<4;i++) line(layer,"mega-glass-line",x+rand(-6,6),y+rand(-6,6),effect,rand(30,72),rand(-70,70),rand(-54,54),rand(-42,42),560+i*55);
    },
    prismCrack(effect, layer, x, y) {
      for (let i=0;i<6;i++) shape(layer,"mega-prism",x+rand(-5,5),y+rand(-5,5),effect,rand(-58,58),rand(-58,58),700+i*40,rand(-180,180));
    },
    mirrorSplinter(effect, layer, x, y) {
      for (let i=0;i<5;i++) line(layer,"mega-mirror-splinter",x,y,effect,rand(18,40),rand(-140,140),rand(-60,60),rand(-50,50),600+i*45);
    },
    lensBloom(effect, layer, x, y) {
      ring(layer,"mega-lens-ring",x,y,effect,720);
      dot(layer,"mega-lens-core",x,y,effect,8,0,0,540,0);
    },
    frostShard(effect, layer, x, y) {
      for (let i=0;i<7;i++) line(layer,"mega-frost",x,y,effect,rand(18,34),i*26+rand(-8,8),Math.cos(i)*rand(22,50),Math.sin(i)*rand(22,50),690+i*30);
    },
    crystalOrbit(effect, layer, x, y) {
      const base=performance.now()/160;
      for (let i=0;i<5;i++){const a=base+i*1.25; shape(layer,"mega-crystal",x+Math.cos(a)*18,y+Math.sin(a)*18,effect,Math.cos(a)*rand(38,62),Math.sin(a)*rand(38,62),700+i*35,a*180/Math.PI);}
    },
    lightThread(effect, layer, x, y) {
      for (let i=0;i<4;i++) line(layer,"mega-light-thread",x+rand(-16,16),y+rand(-16,16),effect,rand(45,85),rand(-40,40),rand(-36,36),rand(-36,36),760+i*40);
    },
    haloSplit(effect, layer, x, y) {
      const a = piece(layer,"mega-halo-left",x,y,effect); fly(a,-30,-6,760,1.25,-8,"megaSplitRing");
      const b = piece(layer,"mega-halo-right",x,y,effect); fly(b,30,6,760,1.25,8,"megaSplitRing");
    },
    starGlint(effect, layer, x, y) {
      for(let i=0;i<4;i++) shape(layer,"mega-star-glint",x+rand(-10,10),y+rand(-10,10),effect,rand(-34,34),rand(-34,34),620+i*50,rand(-90,90));
    },
    flareNeedle(effect, layer, x, y) {
      for (let i=0;i<8;i++){const a=i*Math.PI/4; line(layer,"mega-flare-needle",x,y,effect,rand(28,55),a*180/Math.PI,Math.cos(a)*rand(30,65),Math.sin(a)*rand(30,65),620+i*25);}
    },

    binaryRain(effect, layer, x, y) {
      for(let i=0;i<6;i++) textMark(layer,"mega-code-text",x+rand(-22,22),y+rand(-10,10),effect,pick(["0","1"]),rand(-10,10),rand(42,95),820+i*35,0);
    },
    terminalCaret(effect, layer, x, y) {
      for(let i=0;i<5;i++) textMark(layer,"mega-code-text caret",x+rand(-10,10),y+rand(-10,10),effect,"_",rand(-48,48),rand(-30,30),620+i*40,0);
    },
    bracketOrbit(effect, layer, x, y) {
      const marks=["{","}","[","]","(",")"];
      for(let i=0;i<6;i++){const a=i*Math.PI/3+performance.now()/260; textMark(layer,"mega-code-text bracket",x+Math.cos(a)*18,y+Math.sin(a)*18,effect,marks[i],Math.cos(a)*48,Math.sin(a)*48,720+i*25,a*30);}
    },
    cursorMatrix(effect, layer, x, y) {
      for(let i=0;i<7;i++) textMark(layer,"mega-matrix-cell",x+rand(-25,25),y+rand(-20,20),effect,pick(["01","10","<>","//"]),rand(-28,28),rand(-50,60),760+i*30,0);
    },
    syntaxSparks(effect, layer, x, y) {
      for(let i=0;i<7;i++) textMark(layer,"mega-code-spark",x,y,effect,pick(["*",";","=","=>","/"]),rand(-60,60),rand(-45,45),660+i*30,rand(-40,40));
    },
    commandEcho(effect, layer, x, y) {
      for(let i=0;i<4;i++) textMark(layer,"mega-command-echo",x-i*5,y+i*3,effect,">",rand(-42,10),rand(-16,16),700+i*70,0);
    },
    packetTrace(effect, layer, x, y) {
      for(let i=0;i<4;i++){line(layer,"mega-packet-line",x,y,effect,rand(36,68),rand(-25,25),rand(30,70),rand(-20,20),700+i*45); dot(layer,"mega-packet-dot",x,y,effect,5,rand(35,75),rand(-20,20),700+i*45);}
    },
    scanlineBreak(effect, layer, x, y) {
      for(let i=0;i<5;i++) line(layer,"mega-scanline",x+rand(-8,8),y+(i-2)*7,effect,rand(38,86),0,rand(-70,70),rand(-8,8),580+i*35);
    },
    hexBloom(effect, layer, x, y) {
      for(let i=0;i<6;i++){const a=i*Math.PI/3; textMark(layer,"mega-hex",x,y,effect,"⬡",Math.cos(a)*rand(35,65),Math.sin(a)*rand(35,65),680+i*30,a*180/Math.PI);}
    },
    promptGhost(effect, layer, x, y) {
      for(let i=0;i<4;i++) textMark(layer,"mega-prompt-ghost",x+rand(-8,8),y+rand(-8,8),effect,pick([">","$","~"]),rand(-20,20),rand(-65,-18),780+i*60,0);
    },

    inkMoth(effect, layer, x, y) {
      const l=piece(layer,"mega-ink-wing left",x-6,y,effect), r=piece(layer,"mega-ink-wing right",x+6,y,effect), b=piece(layer,"mega-ink-body",x,y,effect);
      l.style.animation="megaMothLeft 760ms ease-out forwards"; r.style.animation="megaMothRight 760ms ease-out forwards"; b.style.animation="megaMothBody 760ms ease-out forwards";
      setTimeout(()=>{l.remove();r.remove();b.remove();},840);
    },
    paperCuts(effect, layer, x, y) {
      for(let i=0;i<5;i++) line(layer,"mega-paper-cut",x,y,effect,rand(18,45),rand(-120,120),rand(-48,48),rand(-42,42),650+i*40);
    },
    calligraphySmoke(effect, layer, x, y) {
      for(let i=0;i<4;i++) line(layer,"mega-calligraphy",x+rand(-6,6),y+rand(-6,6),effect,rand(34,70),rand(-80,80),rand(-36,36),rand(-54,4),860+i*50);
    },
    tornEdge(effect, layer, x, y) {
      for(let i=0;i<6;i++) shape(layer,"mega-torn-paper",x,y,effect,rand(-55,55),rand(-45,45),700+i*40,rand(-180,180));
    },
    graphiteDust(effect, layer, x, y) {
      for(let i=0;i<8;i++) dot(layer,"mega-graphite",x+rand(-14,14),y+rand(-10,10),effect,rand(2,5),rand(-50,50),rand(-35,45),760+i*22);
    },
    manuscriptFireflies(effect, layer, x, y) {
      for(let i=0;i<5;i++) dot(layer,"mega-manuscript-dot",x+rand(-14,14),y+rand(-14,14),effect,rand(5,9),rand(-35,35),rand(-70,-15),860+i*45);
    },
    foldedCorner(effect, layer, x, y) {
      for(let i=0;i<5;i++) shape(layer,"mega-folded-corner",x,y,effect,rand(-44,44),rand(-44,44),720+i*40,rand(-160,160));
    },
    typewriterGhost(effect, layer, x, y) {
      for(let i=0;i<5;i++) textMark(layer,"mega-typewriter",x+rand(-18,18),y+rand(-8,8),effect,pick(["a","x","/","_",";"]),rand(-18,18),rand(-48,18),740+i*45,0);
    },
    stampBurst(effect, layer, x, y) {
      ring(layer,"mega-stamp-ring",x,y,effect,720);
      for(let i=0;i<5;i++) dot(layer,"mega-stamp-dust",x,y,effect,rand(3,6),rand(-55,55),rand(-45,45),720+i*25);
    },
    vellumSnow(effect, layer, x, y) {
      for(let i=0;i<6;i++) shape(layer,"mega-vellum",x+rand(-18,18),y+rand(-10,10),effect,rand(-22,22),rand(30,88),980+i*50,rand(-120,120));
    },

    orbitNeedle(effect, layer, x, y) {
      const base=performance.now()/180;
      for(let i=0;i<4;i++){const a=base+i*Math.PI/2; line(layer,"mega-orbit-needle",x+Math.cos(a)*18,y+Math.sin(a)*18,effect,rand(26,44),a*180/Math.PI,Math.cos(a)*rand(28,60),Math.sin(a)*rand(28,60),620);}
    },
    gravityWell(effect, layer, x, y) {
      for(let i=0;i<8;i++){const a=i*Math.PI/4; dot(layer,"mega-gravity-dot",x+Math.cos(a)*rand(35,55),y+Math.sin(a)*rand(35,55),effect,rand(3,6),-Math.cos(a)*rand(25,52),-Math.sin(a)*rand(25,52),760+i*25);}
    },
    tinyEclipse(effect, layer, x, y) {
      ring(layer,"mega-eclipse",x,y,effect,820);
      shape(layer,"mega-eclipse-moon",x-18,y,effect,34,0,820,0);
    },
    starMap(effect, layer, x, y) {
      for(let i=0;i<5;i++) line(layer,"mega-star-map-line",x+rand(-20,20),y+rand(-20,20),effect,rand(18,46),rand(-120,120),rand(-28,28),rand(-28,28),760+i*35);
      for(let i=0;i<5;i++) dot(layer,"mega-star-map-dot",x+rand(-20,20),y+rand(-20,20),effect,4,rand(-28,28),rand(-28,28),760+i*35);
    },
    clockworkBits(effect, layer, x, y) {
      for(let i=0;i<6;i++) textMark(layer,"mega-clock-bit",x,y,effect,pick(["•","/","—","×"]),rand(-55,55),rand(-55,55),700+i*30,rand(-180,180));
    },
    magnetShards(effect, layer, x, y) {
      for(let i=0;i<7;i++){const a=rand(0,Math.PI*2); shape(layer,"mega-magnet-shard",x+Math.cos(a)*40,y+Math.sin(a)*40,effect,-Math.cos(a)*rand(30,55),-Math.sin(a)*rand(30,55),680+i*30,rand(-180,180));}
    },
    satellitePulse(effect, layer, x, y) {
      const a=performance.now()/180; dot(layer,"mega-satellite",x+Math.cos(a)*26,y+Math.sin(a)*26,effect,9,Math.cos(a)*56,Math.sin(a)*56,760,a*180/Math.PI); ring(layer,"mega-satellite-ring",x,y,effect,760);
    },
    blackHoleDust(effect, layer, x, y) {
      for(let i=0;i<8;i++){const a=i*.8+performance.now()/200; dot(layer,"mega-black-dust",x+Math.cos(a)*rand(15,45),y+Math.sin(a)*rand(15,45),effect,rand(3,7),-Math.cos(a)*rand(8,28),-Math.sin(a)*rand(8,28),880+i*25);}
    },
    gearSparks(effect, layer, x, y) {
      for(let i=0;i<6;i++) textMark(layer,"mega-gear-spark",x,y,effect,pick(["⚙","×","/","+"]),rand(-52,52),rand(-52,52),720+i*25,rand(-180,180));
    },
    compassFlare(effect, layer, x, y) {
      [[0,-1],[1,0],[0,1],[-1,0]].forEach((v,i)=>line(layer,"mega-compass",x,y,effect,rand(30,50),i*90,v[0]*rand(40,70),v[1]*rand(40,70),680+i*40));
    }
  };

  function clearBasic(layer) {
    const s = BASIC_STATES.get(layer);
    if (!s) return;
    s.dead = true;
    s.node.remove();
    BASIC_STATES.delete(layer);
  }

  function makeBasic(effect, layer, x, y) {
    clearBasic(layer);
    const p = pal(effect);
    const node = document.createElement("span");
    node.className = "basic-follow " + effect.key;
    node.setAttribute("aria-hidden","true");
    node.style.left = x + "px";
    node.style.top = y + "px";
    node.style.setProperty("--a", p.a);
    node.style.setProperty("--b", p.b);
    node.style.setProperty("--ink", p.ink);
    layer.appendChild(node);
    const state = { key: effect.key, node, x, y, tx:x, ty:y, vx:0, vy:0, angle:0, dead:false };
    BASIC_STATES.set(layer, state);
    requestAnimationFrame(() => animateBasic(layer, state));
    return state;
  }

  function animateBasic(layer, s) {
    if (s.dead || BASIC_STATES.get(layer) !== s) return;
    const dx=s.tx-s.x, dy=s.ty-s.y;
    s.vx += dx*.12; s.vy += dy*.12;
    s.vx *= .72; s.vy *= .72;
    s.x += s.vx; s.y += s.vy;
    if (Math.hypot(s.vx,s.vy)>.08) s.angle = Math.atan2(s.vy,s.vx);
    s.node.style.left=s.x+"px";
    s.node.style.top=s.y+"px";
    s.node.style.transform="translate(-50%,-50%) rotate("+(s.angle*180/Math.PI)+"deg)";
    requestAnimationFrame(() => animateBasic(layer, s));
  }

  COLD_FX.spawn = function(effect, layer, x, y) {
    if (effect && MEGA_KEYS.has(effect.key)) {
      if (effect.kind === "mega-basic") {
        let s = BASIC_STATES.get(layer);
        if (!s || s.key !== effect.key) s = makeBasic(effect, layer, x, y);
        s.tx = x; s.ty = y;
        return;
      }

      const fn = RICH[effect.mode];
      if (fn) {
        fn(effect, layer, x, y);
        return;
      }
    }
    oldSpawn(effect, layer, x, y);
  };

  COLD_FX.clear = function(layer) {
    clearBasic(layer);
    if (oldClear) oldClear(layer);
    else layer.innerHTML = "";
  };
})();
