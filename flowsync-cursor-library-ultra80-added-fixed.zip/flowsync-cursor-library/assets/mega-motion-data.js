(function () {
  const addonCategories = [
    {
        "id":  "mega-ash-smoke",
        "num":  "01",
        "title":  "Ash & Smoke",
        "desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "icon":  "ash",
        "effects":  [
                        "pm-ash-spiral",
                        "pm-ember-veil",
                        "pm-smoke-knot",
                        "pm-cinder-lift",
                        "pm-soot-comet",
                        "pm-burnt-pollen",
                        "pm-charcoal-rain",
                        "pm-vapor-stitch",
                        "pm-ghost-ash",
                        "pm-coal-flicker"
                    ]
    },
    {
        "id":  "mega-glass-light",
        "num":  "02",
        "title":  "Glass & Light",
        "desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "icon":  "glass",
        "effects":  [
                        "pm-glass-scratch",
                        "pm-prism-crack",
                        "pm-mirror-splinter",
                        "pm-lens-bloom",
                        "pm-frost-shard",
                        "pm-crystal-orbit",
                        "pm-light-thread",
                        "pm-halo-split",
                        "pm-star-glint",
                        "pm-flare-needle"
                    ]
    },
    {
        "id":  "mega-code-data",
        "num":  "03",
        "title":  "Code & Data",
        "desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "icon":  "code",
        "effects":  [
                        "pm-binary-rain",
                        "pm-terminal-caret",
                        "pm-bracket-orbit",
                        "pm-cursor-matrix",
                        "pm-syntax-sparks",
                        "pm-command-echo",
                        "pm-packet-trace",
                        "pm-scanline-break",
                        "pm-hex-bloom",
                        "pm-prompt-ghost"
                    ]
    },
    {
        "id":  "mega-ink-paper",
        "num":  "04",
        "title":  "Ink & Paper",
        "desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "icon":  "ink",
        "effects":  [
                        "pm-ink-moth",
                        "pm-paper-cuts",
                        "pm-calligraphy-smoke",
                        "pm-torn-edge",
                        "pm-graphite-dust",
                        "pm-manuscript-fireflies",
                        "pm-folded-corner",
                        "pm-typewriter-ghost",
                        "pm-stamp-burst",
                        "pm-vellum-snow"
                    ]
    },
    {
        "id":  "mega-cosmic-mech",
        "num":  "05",
        "title":  "Cosmic & Mechanical",
        "desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "icon":  "cosmic",
        "effects":  [
                        "pm-orbit-needle",
                        "pm-gravity-well",
                        "pm-tiny-eclipse",
                        "pm-star-map",
                        "pm-clockwork-bits",
                        "pm-magnet-shards",
                        "pm-satellite-pulse",
                        "pm-black-hole-dust",
                        "pm-gear-sparks",
                        "pm-compass-flare"
                    ]
    },
    {
        "id":  "basic-cursor-marks",
        "num":  "06",
        "title":  "Basic Cursor Marks",
        "desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "icon":  "basic",
        "effects":  [
                        "bc-soft-dot",
                        "bc-clean-ring",
                        "bc-cross-plus",
                        "bc-tiny-plus",
                        "bc-cursor-halo",
                        "bc-square-pulse",
                        "bc-triangle-tick",
                        "bc-underline-trail",
                        "bc-corner-ticks",
                        "bc-mini-dash"
                    ]
    },
    {
        "id":  "basic-interface-kit",
        "num":  "07",
        "title":  "Interface Basics",
        "desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "icon":  "ui",
        "effects":  [
                        "bc-default-pointer",
                        "bc-caret-blink",
                        "bc-target-dot",
                        "bc-click-ripple",
                        "bc-small-spark",
                        "bc-plain-ring",
                        "bc-follow-bar",
                        "bc-axis-mark",
                        "bc-mono-dot",
                        "bc-quiet-bubble"
                    ]
    }
];
  const addonEffects = [
    {
        "key":  "pm-ash-spiral",
        "name":  "Ash Spiral",
        "desc":  "Ash dots spiral outward like burnt paper.",
        "kind":  "mega-rich",
        "mode":  "ashSpiral",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-ember-veil",
        "name":  "Ember Veil",
        "desc":  "Warm ember specks lift and vanish in a loose veil.",
        "kind":  "mega-rich",
        "mode":  "emberVeil",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-smoke-knot",
        "name":  "Smoke Knot",
        "desc":  "Soft smoke blobs fold around the cursor before fading.",
        "kind":  "mega-rich",
        "mode":  "smokeKnot",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-cinder-lift",
        "name":  "Cinder Lift",
        "desc":  "Sharp cinder flakes rise with a dry upward pull.",
        "kind":  "mega-rich",
        "mode":  "cinderLift",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-soot-comet",
        "name":  "Soot Comet",
        "desc":  "Dark soot marks shoot away with a tiny comet tail.",
        "kind":  "mega-rich",
        "mode":  "sootComet",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-burnt-pollen",
        "name":  "Burnt Pollen",
        "desc":  "Small pollen-like ash clusters scatter in uneven groups.",
        "kind":  "mega-rich",
        "mode":  "burntPollen",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-charcoal-rain",
        "name":  "Charcoal Rain",
        "desc":  "Muted charcoal grains fall down with gravity.",
        "kind":  "mega-rich",
        "mode":  "charcoalRain",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-vapor-stitch",
        "name":  "Vapor Stitch",
        "desc":  "Broken vapor stitches trail behind the pointer.",
        "kind":  "mega-rich",
        "mode":  "vaporStitch",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-ghost-ash",
        "name":  "Ghost Ash",
        "desc":  "Pale ghost-ash rings drift and dissolve slowly.",
        "kind":  "mega-rich",
        "mode":  "ghostAsh",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-coal-flicker",
        "name":  "Coal Flicker",
        "desc":  "Tiny coal sparks flicker close to the cursor.",
        "kind":  "mega-rich",
        "mode":  "coalFlicker",
        "cat_id":  "mega-ash-smoke",
        "cat_num":  "01",
        "cat_title":  "Ash & Smoke",
        "cat_desc":  "Dry ash, soot, vapor and ember-style cursor motion.",
        "cat_icon":  "ash",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-glass-scratch",
        "name":  "Glass Scratch",
        "desc":  "Sharp glass scratches slice and disappear.",
        "kind":  "mega-rich",
        "mode":  "glassScratch",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-prism-crack",
        "name":  "Prism Crack",
        "desc":  "Angular prism shards burst from the pointer.",
        "kind":  "mega-rich",
        "mode":  "prismCrack",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-mirror-splinter",
        "name":  "Mirror Splinter",
        "desc":  "Small mirror splinters rotate away quickly.",
        "kind":  "mega-rich",
        "mode":  "mirrorSplinter",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-lens-bloom",
        "name":  "Lens Bloom",
        "desc":  "A thin lens ring blooms outward with soft light.",
        "kind":  "mega-rich",
        "mode":  "lensBloom",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-frost-shard",
        "name":  "Frost Shard",
        "desc":  "Cold shard needles fan out with crisp motion.",
        "kind":  "mega-rich",
        "mode":  "frostShard",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-crystal-orbit",
        "name":  "Crystal Orbit",
        "desc":  "Tiny crystal diamonds orbit before snapping out.",
        "kind":  "mega-rich",
        "mode":  "crystalOrbit",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-light-thread",
        "name":  "Light Thread",
        "desc":  "Thin light threads cross the cursor and fade.",
        "kind":  "mega-rich",
        "mode":  "lightThread",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-halo-split",
        "name":  "Halo Split",
        "desc":  "A halo splits into two offset rings.",
        "kind":  "mega-rich",
        "mode":  "haloSplit",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-star-glint",
        "name":  "Star Glint",
        "desc":  "Small star glints pop with a premium sparkle.",
        "kind":  "mega-rich",
        "mode":  "starGlint",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-flare-needle",
        "name":  "Flare Needle",
        "desc":  "Long flare needles radiate from the cursor.",
        "kind":  "mega-rich",
        "mode":  "flareNeedle",
        "cat_id":  "mega-glass-light",
        "cat_num":  "02",
        "cat_title":  "Glass & Light",
        "cat_desc":  "Clean scratches, prism cuts, bloom rings and needle-light motion.",
        "cat_icon":  "glass",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-binary-rain",
        "name":  "Binary Rain",
        "desc":  "Tiny binary marks fall and fade near the cursor.",
        "kind":  "mega-rich",
        "mode":  "binaryRain",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-terminal-caret",
        "name":  "Terminal Caret",
        "desc":  "Blinking terminal carets jump away from the cursor.",
        "kind":  "mega-rich",
        "mode":  "terminalCaret",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-bracket-orbit",
        "name":  "Bracket Orbit",
        "desc":  "Code brackets orbit briefly around the pointer.",
        "kind":  "mega-rich",
        "mode":  "bracketOrbit",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-cursor-matrix",
        "name":  "Cursor Matrix",
        "desc":  "Mini matrix cells drift and break apart.",
        "kind":  "mega-rich",
        "mode":  "cursorMatrix",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-syntax-sparks",
        "name":  "Syntax Sparks",
        "desc":  "Code symbols pop like sparks around the cursor.",
        "kind":  "mega-rich",
        "mode":  "syntaxSparks",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-command-echo",
        "name":  "Command Echo",
        "desc":  "Small command echoes repeat and fade behind movement.",
        "kind":  "mega-rich",
        "mode":  "commandEcho",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-packet-trace",
        "name":  "Packet Trace",
        "desc":  "Packet dots trace short network-like lines.",
        "kind":  "mega-rich",
        "mode":  "packetTrace",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-scanline-break",
        "name":  "Scanline Break",
        "desc":  "Scan bars tear apart horizontally.",
        "kind":  "mega-rich",
        "mode":  "scanlineBreak",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-hex-bloom",
        "name":  "Hex Bloom",
        "desc":  "Hex marks bloom outward in a radial burst.",
        "kind":  "mega-rich",
        "mode":  "hexBloom",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-prompt-ghost",
        "name":  "Prompt Ghost",
        "desc":  "Ghosted prompt symbols float upward and vanish.",
        "kind":  "mega-rich",
        "mode":  "promptGhost",
        "cat_id":  "mega-code-data",
        "cat_num":  "03",
        "cat_title":  "Code & Data",
        "cat_desc":  "Binary, brackets, packets, scanlines and terminal-inspired motion.",
        "cat_icon":  "code",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-ink-moth",
        "name":  "Ink Moth",
        "desc":  "Two ink wings open and dissolve like a tiny moth.",
        "kind":  "mega-rich",
        "mode":  "inkMoth",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-paper-cuts",
        "name":  "Paper Cuts",
        "desc":  "Thin paper cut marks flick away from the pointer.",
        "kind":  "mega-rich",
        "mode":  "paperCuts",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-calligraphy-smoke",
        "name":  "Calligraphy Smoke",
        "desc":  "Ink strokes curl like smoke and disappear.",
        "kind":  "mega-rich",
        "mode":  "calligraphySmoke",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-torn-edge",
        "name":  "Torn Edge",
        "desc":  "Ripped paper fragments scatter with rough motion.",
        "kind":  "mega-rich",
        "mode":  "tornEdge",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-graphite-dust",
        "name":  "Graphite Dust",
        "desc":  "Muted graphite dust trails behind cursor movement.",
        "kind":  "mega-rich",
        "mode":  "graphiteDust",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-manuscript-fireflies",
        "name":  "Manuscript Fireflies",
        "desc":  "Tiny manuscript dots glow and drift softly.",
        "kind":  "mega-rich",
        "mode":  "manuscriptFireflies",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-folded-corner",
        "name":  "Folded Corner",
        "desc":  "Small folded-corner triangles flip and fade.",
        "kind":  "mega-rich",
        "mode":  "foldedCorner",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-typewriter-ghost",
        "name":  "Typewriter Ghost",
        "desc":  "Ghost letters appear like old typewriter marks.",
        "kind":  "mega-rich",
        "mode":  "typewriterGhost",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-stamp-burst",
        "name":  "Stamp Burst",
        "desc":  "A stamp-like pulse breaks into paper dust.",
        "kind":  "mega-rich",
        "mode":  "stampBurst",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-vellum-snow",
        "name":  "Vellum Snow",
        "desc":  "Soft vellum flakes drift with paper-like weight.",
        "kind":  "mega-rich",
        "mode":  "vellumSnow",
        "cat_id":  "mega-ink-paper",
        "cat_num":  "04",
        "cat_title":  "Ink & Paper",
        "cat_desc":  "Ink wings, torn paper, graphite dust and typewriter-like cursor motion.",
        "cat_icon":  "ink",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-orbit-needle",
        "name":  "Orbit Needle",
        "desc":  "Thin needle marks orbit and snap away.",
        "kind":  "mega-rich",
        "mode":  "orbitNeedle",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  1,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-gravity-well",
        "name":  "Gravity Well",
        "desc":  "Dust bends inward then collapses into the cursor.",
        "kind":  "mega-rich",
        "mode":  "gravityWell",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  2,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-tiny-eclipse",
        "name":  "Tiny Eclipse",
        "desc":  "A small eclipse ring crosses and fades.",
        "kind":  "mega-rich",
        "mode":  "tinyEclipse",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  3,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-star-map",
        "name":  "Star Map",
        "desc":  "Tiny map points connect like a small constellation.",
        "kind":  "mega-rich",
        "mode":  "starMap",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  4,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-clockwork-bits",
        "name":  "Clockwork Bits",
        "desc":  "Small mechanical ticks rotate around the pointer.",
        "kind":  "mega-rich",
        "mode":  "clockworkBits",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  5,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-magnet-shards",
        "name":  "Magnet Shards",
        "desc":  "Shard marks pull inward then scatter outward.",
        "kind":  "mega-rich",
        "mode":  "magnetShards",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  6,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-satellite-pulse",
        "name":  "Satellite Pulse",
        "desc":  "A satellite-like dot orbits then shoots away.",
        "kind":  "mega-rich",
        "mode":  "satellitePulse",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  7,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-black-hole-dust",
        "name":  "Black Hole Dust",
        "desc":  "Dust circles the cursor and collapses darkly.",
        "kind":  "mega-rich",
        "mode":  "blackHoleDust",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  8,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-gear-sparks",
        "name":  "Gear Sparks",
        "desc":  "Gear-tooth sparks rotate and break apart.",
        "kind":  "mega-rich",
        "mode":  "gearSparks",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  9,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "pm-compass-flare",
        "name":  "Compass Flare",
        "desc":  "Compass ticks snap in four directions.",
        "kind":  "mega-rich",
        "mode":  "compassFlare",
        "cat_id":  "mega-cosmic-mech",
        "cat_num":  "05",
        "cat_title":  "Cosmic & Mechanical",
        "cat_desc":  "Orbit, gravity, gears, compass sparks and mechanical cursor motion.",
        "cat_icon":  "cosmic",
        "index":  10,
        "dark":  {
                     "a":  "#f1e7d6",
                     "b":  "#9d8c6e",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#211c16",
                      "b":  "#70614c",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-soft-dot",
        "name":  "Soft Dot",
        "desc":  "A quiet dot follows the cursor with a soft delay.",
        "kind":  "mega-basic",
        "mode":  "softDot",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  1,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-clean-ring",
        "name":  "Clean Ring",
        "desc":  "A thin ring follows the pointer cleanly.",
        "kind":  "mega-basic",
        "mode":  "cleanRing",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  2,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-cross-plus",
        "name":  "Cross Plus",
        "desc":  "A minimal plus mark follows the cursor.",
        "kind":  "mega-basic",
        "mode":  "crossPlus",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  3,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-tiny-plus",
        "name":  "Tiny Plus",
        "desc":  "A small plus mark with lighter motion.",
        "kind":  "mega-basic",
        "mode":  "tinyPlus",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  4,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-cursor-halo",
        "name":  "Cursor Halo",
        "desc":  "A subtle halo follows cursor movement.",
        "kind":  "mega-basic",
        "mode":  "cursorHalo",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  5,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-square-pulse",
        "name":  "Square Pulse",
        "desc":  "A small square pulse tracks the pointer.",
        "kind":  "mega-basic",
        "mode":  "squarePulse",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  6,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-triangle-tick",
        "name":  "Triangle Tick",
        "desc":  "A tiny triangle tick follows with rotation.",
        "kind":  "mega-basic",
        "mode":  "triangleTick",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  7,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-underline-trail",
        "name":  "Underline Trail",
        "desc":  "A small underline bar follows beneath the cursor.",
        "kind":  "mega-basic",
        "mode":  "underlineTrail",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  8,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-corner-ticks",
        "name":  "Corner Ticks",
        "desc":  "Four small corner ticks follow the pointer.",
        "kind":  "mega-basic",
        "mode":  "cornerTicks",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  9,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-mini-dash",
        "name":  "Mini Dash",
        "desc":  "A tiny dash follows cursor direction.",
        "kind":  "mega-basic",
        "mode":  "miniDash",
        "cat_id":  "basic-cursor-marks",
        "cat_num":  "06",
        "cat_title":  "Basic Cursor Marks",
        "cat_desc":  "Simple clean cursor-follow marks: rings, crosses, squares and small trails.",
        "cat_icon":  "basic",
        "index":  10,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-default-pointer",
        "name":  "Default Pointer",
        "desc":  "A small pointer arrow follows the cursor.",
        "kind":  "mega-basic",
        "mode":  "defaultPointer",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  1,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-caret-blink",
        "name":  "Caret Blink",
        "desc":  "A blinking caret follows like a text cursor.",
        "kind":  "mega-basic",
        "mode":  "caretBlink",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  2,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-target-dot",
        "name":  "Target Dot",
        "desc":  "A clean target dot follows cursor movement.",
        "kind":  "mega-basic",
        "mode":  "targetDot",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  3,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-click-ripple",
        "name":  "Click Ripple",
        "desc":  "A simple ripple pulse follows the pointer.",
        "kind":  "mega-basic",
        "mode":  "clickRipple",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  4,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-small-spark",
        "name":  "Small Spark",
        "desc":  "A tiny spark mark follows with light rotation.",
        "kind":  "mega-basic",
        "mode":  "smallSpark",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  5,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-plain-ring",
        "name":  "Plain Ring",
        "desc":  "A plain neutral ring follows the pointer.",
        "kind":  "mega-basic",
        "mode":  "plainRing",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  6,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-follow-bar",
        "name":  "Follow Bar",
        "desc":  "A short bar follows cursor direction.",
        "kind":  "mega-basic",
        "mode":  "followBar",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  7,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-axis-mark",
        "name":  "Axis Mark",
        "desc":  "A small x/y axis mark follows the cursor.",
        "kind":  "mega-basic",
        "mode":  "axisMark",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  8,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-mono-dot",
        "name":  "Mono Dot",
        "desc":  "A simple mono dot with low movement delay.",
        "kind":  "mega-basic",
        "mode":  "monoDot",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  9,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    },
    {
        "key":  "bc-quiet-bubble",
        "name":  "Quiet Bubble",
        "desc":  "A small soft bubble follows the cursor.",
        "kind":  "mega-basic",
        "mode":  "quietBubble",
        "cat_id":  "basic-interface-kit",
        "cat_num":  "07",
        "cat_title":  "Interface Basics",
        "cat_desc":  "Default UI cursor helpers with simple motion and clean shapes.",
        "cat_icon":  "ui",
        "index":  10,
        "dark":  {
                     "a":  "#efe6d6",
                     "b":  "#a2947b",
                     "ink":  "#17131f"
                 },
        "light":  {
                      "a":  "#23201b",
                      "b":  "#766b5a",
                      "ink":  "#faf8f1"
                  }
    }
];
  const addonCategoryIds = new Set(addonCategories.map((cat) => cat.id));
  const addonEffectKeys = new Set(addonEffects.map((fx) => fx.key));

  const weakCategoryIds = new Set([
    "animal-friends",
    "wild-creatures",
    "classic-basics",
    "premium-motion",
    "mega-ash-smoke",
    "mega-glass-light",
    "mega-code-data",
    "mega-ink-paper",
    "mega-cosmic-mech",
    "basic-cursor-marks",
    "basic-interface-kit"
  ]);

  const weakEffectKeys = new Set([
    "cat-paw","butterfly-pair","bird-flock","rabbit-hop","dragonfly-dash",
    "spider-crawler","cockroach-skitter","crocodile-crawl","crocodile-snap",
    "mini-dragon","scorpion-tail","gecko-dash","bat-flutter","crab-walk",
    "default-dot","default-ring","default-crosshair","corner-bracket","click-flash",
    "ash-spiral","bone-embers","glass-scratch","cursor-lantern","orbit-needle",
    "ink-moth","glitch-scan","dark-snow","ash-ribbon","terminal-sparks"
  ]);

  window.COLD_DATA = (window.COLD_DATA || [])
    .filter((cat) => !weakCategoryIds.has(cat.id) && !addonCategoryIds.has(cat.id))
    .map((cat) => ({
      ...cat,
      effects: (cat.effects || []).filter((key) => !weakEffectKeys.has(key) && !addonEffectKeys.has(key))
    }))
    .filter((cat) => (cat.effects || []).length > 0);

  window.COLD_EFFECTS = (window.COLD_EFFECTS || [])
    .filter((fx) => !weakEffectKeys.has(fx.key) && !addonEffectKeys.has(fx.key));

  const start = window.COLD_DATA.length + 1;

  addonCategories.forEach((cat, index) => {
    const num = String(start + index).padStart(2, "0");
    const normalized = { ...cat, num };
    window.COLD_DATA.push(normalized);

    addonEffects
      .filter((fx) => fx.cat_id === cat.id)
      .forEach((fx) => {
        window.COLD_EFFECTS.push({
          ...fx,
          cat_num: num,
          cat_title: normalized.title,
          cat_desc: normalized.desc,
          cat_icon: normalized.icon
        });
      });
  });

  window.MEGA_MOTION_CATEGORIES = addonCategories;
  window.MEGA_MOTION_EFFECTS = addonEffects;
})();